<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Student_Management extends Controller
{
    //
    function layout()
    { return view("layout");
}
}
