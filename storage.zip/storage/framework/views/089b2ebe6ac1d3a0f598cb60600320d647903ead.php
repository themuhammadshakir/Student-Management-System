
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Enrollments </div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Enroll_no : <?php echo e($enrollments->enrollment_no); ?></h5>
            <p class="card-text">Batch_id : <?php echo e($enrollments->batch_id); ?></p>
            <p class="card-text">Student_id : <?php echo e($enrollments->student_id); ?></p>
            <p class="card-text">Joindate : <?php echo e($enrollments->joindate); ?></p>
            <p class="card-text">Fee : <?php echo e($enrollments->fee); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Student_Management\resources\views/enrollments/show.blade.php ENDPATH**/ ?>