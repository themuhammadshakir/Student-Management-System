@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">Paymentes</div>
    <div class="card-body">
        <form action="{{ url('payment') }}" method="post">
            {!! csrf_field() !!}
            <label> Enrollment_no</label></br>
            <select name='enrollment_no' id='enrollment_no' class='form-control'></br></br>
                @foreach($enrollments as $id=>$enrollment_no)
                    <option value='{{$id}}'>{{$enrollment_no}}
                @endforeach
            </select>
            <label>Paid_date</label></br>
            <input type="date" name="paid_date" id="paid_date" class="form-control"></br>
            <br><label>Amount</label></br>
            <input type="text" name="amount" id="amount" class="form-control"></br>
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@stop