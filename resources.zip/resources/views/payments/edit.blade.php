@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">Payment Edit</div>
    <div class="card-body">
        <form action="{{ url('payment/' .$payments->id) }}" method="post">
            {!! csrf_field() !!}
            @method("PATCH")
            <input type="hidden" name="id" id="id" value="{{$payments->id}}" id="id" />
            <label>Enrollment_no</label></br>
            <input type="text" name="enrollment_no" id="enrollment_no" value="{{$payments->name}}" class="form-control"></br>
            <label>Paid_Date</label></br>
            <input type="text" name="paid_date" id="paid_date" value="{{$payments->paid_date}}" class="form-control"></br>
            <label>Amount</label></br>
            <input type="text" name="amount" id="amount" value="{{$payments->amount}}" class="form-control"></br>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@stop