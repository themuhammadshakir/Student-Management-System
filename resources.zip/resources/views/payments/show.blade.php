@extends('layout')
@section('content')
<div class="card">
    <div class="card-header">Payments</div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Enrollment_no : {{ $payments->enrollment_no  }}</h5>
            <p class="card-text">Paid_Date: {{ $payments->paid_date}}</p>
            <p class="card-text">Amount : {{ $payments->amount }}</p>
        </div>
    </div>
</div>
@endsection