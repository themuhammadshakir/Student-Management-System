@extends('layout')
@section('content')
<div class="card">
    <div class="card-header">Enrollments </div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Enroll_no : {{ $enrollments->enrollment_no }}</h5>
            <p class="card-text">Batch_id : {{ $enrollments->batch_id }}</p>
            <p class="card-text">Student_id : {{ $enrollments->student_id }}</p>
            <p class="card-text">Joindate : {{ $enrollments->joindate }}</p>
            <p class="card-text">Fee : {{ $enrollments->fee }}</p>
        </div>
    </div>
</div>
@endsection