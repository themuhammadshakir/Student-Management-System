@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">nrollment Page</div>
    <div class="card-body">
        <form action="{{ url('enrollment/' .$enrollments->id) }}" method="post">
            {!! csrf_field() !!}
            @method("PATCH")
            class="form-control"></br>
            <label>Enroll_no</label></br>
            <input type="text" name="enrollment_no	" id="enrollment_no	" class="form-control"> value="{{$enrollments->enroll_no}}"</br>
            <label>Batch_id</label></br>
            <input type="text" name="batch_id" id="batch_id" class="form-control"> value="{{$enrollments->batch_id}}"</br>
            <label>Student_id</label></br>
            <input type="text" name="Student_id" id="Student_id" class="form-control"> value="{{$enrollments->student_id}}"</br>
            <label>Joindate</label></br>
            <input type="date" name="joindate" id="joindate" class="form-control"> value="{{$enrollments->joindate}}"</br>
            <label>Fee</label></br>
            <input type="text" name="fee" id="fee" class="form-control"> value="{{$enrollments->fee}}"</br>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@stop